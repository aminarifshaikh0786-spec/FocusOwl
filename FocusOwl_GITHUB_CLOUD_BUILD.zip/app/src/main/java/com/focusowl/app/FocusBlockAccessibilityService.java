package com.focusowl.app;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.accessibility.AccessibilityEvent;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class FocusBlockAccessibilityService extends AccessibilityService {
    private static volatile boolean sessionActive=false;
    private static final Set<String> blocked = Collections.synchronizedSet(new HashSet<>());
    private WindowManager wm;
    private View overlay;
    private final Handler handler = new Handler();
    private String lastPackage="";

    public static void setSession(boolean active, Set<String> packages){
        sessionActive=active;
        blocked.clear();
        if(packages!=null) blocked.addAll(packages);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(!sessionActive || event==null) return;
        CharSequence pn=event.getPackageName();
        if(pn==null) return;
        String pkg=pn.toString();
        if(pkg.equals(getPackageName())) return;
        if(blocked.contains(pkg)){
            lastPackage=pkg;
            showBlocker();
            performGlobalAction(GLOBAL_ACTION_HOME);
            handler.postDelayed(this::showBlocker,120);
        } else if(overlay!=null && !pkg.equals(getPackageName())) {
            removeBlocker();
        }
    }

    private void showBlocker(){
        if(overlay!=null) return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(50,50,50,50);
        box.setBackgroundColor(Color.WHITE);
        TextView t=new TextView(this); t.setText("🦉  FocusOwl\n\nThis app is locked during your focus session.\n\nReturn to your study session to continue."); t.setTextSize(20); t.setTextColor(Color.rgb(24,35,58)); t.setGravity(Gravity.CENTER);
        Button b=new Button(this); b.setText("Open FocusOwl"); b.setOnClickListener(v -> { removeBlocker(); Intent i=getPackageManager().getLaunchIntentForPackage(getPackageName()); if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i);} });
        box.addView(t); box.addView(b);
        int type=WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,type,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        wm.addView(box,lp); overlay=box;
    }

    private void removeBlocker(){ if(overlay!=null){ try{wm.removeView(overlay);}catch(Exception ignored){} overlay=null; } }
    @Override public void onInterrupt(){ removeBlocker(); }
    @Override public void onDestroy(){ sessionActive=false; blocked.clear(); removeBlocker(); super.onDestroy(); }
}
