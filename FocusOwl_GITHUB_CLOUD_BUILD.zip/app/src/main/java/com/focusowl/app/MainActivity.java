package com.focusowl.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.accessibility.AccessibilityManager;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    public static class AndroidBridge {
        private final MainActivity activity;
        AndroidBridge(MainActivity activity){ this.activity = activity; }

        @JavascriptInterface public void openAccessibilitySettings(){
            activity.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        @JavascriptInterface public boolean isBlockingEnabled(){ return isAccessibilityEnabled(activity); }

        @JavascriptInterface public void setSessionActive(boolean active, String appsJson){
            Set<String> packages = mapLabels(appsJson);
            FocusBlockAccessibilityService.setSession(active, packages);
            if(active && !isAccessibilityEnabled(activity)) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Enable FocusOwl in Accessibility settings for real app blocking.", Toast.LENGTH_LONG).show());
            }
        }

        private static Set<String> mapLabels(String json){
            Set<String> out = new HashSet<>();
            try {
                JSONArray a = new JSONArray(json);
                for(int i=0;i<a.length();i++){
                    String label=a.optString(i);
                    if("YouTube".equals(label)) out.add("com.google.android.youtube");
                    if("Instagram".equals(label)) out.add("com.instagram.android");
                    if("Facebook".equals(label)) out.add("com.facebook.katana");
                    if("WhatsApp".equals(label)) out.add("com.whatsapp");
                }
            } catch(Exception ignored) {}
            return out;
        }

        private static boolean isAccessibilityEnabled(Context c){
            AccessibilityManager am=(AccessibilityManager)c.getSystemService(Context.ACCESSIBILITY_SERVICE);
            if(am==null) return false;
            for(AccessibilityServiceInfo i: am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)){
                ServiceInfoHolder h=new ServiceInfoHolder(i);
                if(h.component!=null && h.component.getPackageName().equals(c.getPackageName())) return true;
            }
            return false;
        }
        private static class ServiceInfoHolder {
            ComponentName component;
            ServiceInfoHolder(AccessibilityServiceInfo i){ try{ component=i.getResolveInfo().serviceInfo.getComponentName(); }catch(Exception ignored){} }
        }
    }
}
